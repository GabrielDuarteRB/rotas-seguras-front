export interface OcorrenciaGetAllInterface {
  id_pessoa?: string
}