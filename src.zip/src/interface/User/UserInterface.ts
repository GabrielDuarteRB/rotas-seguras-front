export interface UserInterface {
  id: string
  nome: string
  email: string
  is_active:  boolean
}