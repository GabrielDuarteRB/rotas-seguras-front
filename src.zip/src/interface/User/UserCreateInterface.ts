export interface UserCreateInterface {
  nome: string
  email: string
  senha: string
}