export default [
  { label: 'Furto', value: "1" },
  { label: 'Roubo', value: "2" },
  { label: 'Agressão', value: "3" },
  { label: 'Outros', value: "4" }
]
