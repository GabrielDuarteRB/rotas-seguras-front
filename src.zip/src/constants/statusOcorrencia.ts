export default [
  { label: 'Pendente', value: "1" },
  { label: 'Em analise', value: "2" },
  { label: 'Resolvido', value: "3" },
  { label: 'Cancelado', value: "4" }
]
